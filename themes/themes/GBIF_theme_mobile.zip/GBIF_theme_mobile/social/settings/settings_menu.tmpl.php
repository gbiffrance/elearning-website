<?php //include this file in all the settings template under the html/settings/ directory ?>
<ul class="social_inline_menu">
<!--	<li class="inlinelist"><a href="<?php echo 'mods/social/settings.php?n=account_settings'; ?>"><?php echo _AT('account_settings'); ?></a></li> -->
	<li class="inlinelist"><a href="<?php echo AT_SOCIAL_BASENAME.'settings.php?n=privacy_settings'; ?>"><?php echo _AT('privacy_settings'); ?></a></li>
	<li class="inlinelist"><a href="<?php echo AT_SOCIAL_BASENAME.'settings.php?n=application_settings'; ?>"><?php echo _AT('application_settings'); ?></a></li>
</ul>